# Join Discussion Group

For users in other languages(not Chinese), please keep using [Github issue tracker](https://github.com/ly525/luban-h5/issues). 🤟

---

<Vssue issueId="11" />