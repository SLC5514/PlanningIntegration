## The api for Luban-H5 powered by [Strapi](https://github.com/strapi/strapi/)
#!zh: 鲁班H5的后端接口，由 [Strapi](https://github.com/strapi/strapi/) 强力驱动



## Getting Started(English)
<a href="https://ly525.github.io/luban-h5/en/getting-started/quick-start.html" target="_blank">Read the Getting Started tutorial</a>

## 快速上手(中文)
<a href="https://ly525.github.io/luban-h5/zh/getting-started/quick-start.html" target="_blank">请阅读快速上手指南</a>
