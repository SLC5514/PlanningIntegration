# 鲁班H5 v.1.8.1至 v.1.8.2 迁移指南
升级`鲁班H5`版本至 `v.1.8.2`.

主要修改请参见[v1.8.2 release log](https://github.com/ly525/luban-h5/releases/tag/v1.8.2)



将 鲁班H5 升级到`v.1.8.2` 比较简单，只要执行如下命令即可：

```bash
# pull 最新代码
# 重新编译预览模块即可
./luban-h5 rebuild_engine
```

如果有疑问，提 [issue](https://github.com/ly525/luban-h5/issues) 即可