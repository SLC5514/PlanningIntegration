# 表单提交

1. 找到页面中所有 input类型 且 包含 data-lbp-form-input 属性的元素，获取其 value。其对应的 key 为该组件对应的uuid
2. 构建一个 Form Data，使用 ajax提交即可

---

> 欢迎大家到[鲁班H5-社区](https://support.qq.com/products/93432/) 交流，在这里可以提问、反馈意见和建议，与作者直接互动


<Vssue issueId="13" />