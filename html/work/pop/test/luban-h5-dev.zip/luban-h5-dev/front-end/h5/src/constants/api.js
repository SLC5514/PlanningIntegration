export const API_ORIGIN = process.env.NODE_ENV === 'production' ? 'https://luban-h5-api.herokuapp.com' : 'http://localhost:1337' // for local dev
