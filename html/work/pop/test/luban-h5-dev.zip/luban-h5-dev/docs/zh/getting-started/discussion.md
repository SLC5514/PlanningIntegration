# 社区与交流群


### 论坛地址：[鲁班H5-社区](https://support.qq.com/products/93432/)


### 交流群
| 钉钉群  | 微信公众号  |  微信 |
|---|---|---|
| <img src="https://user-images.githubusercontent.com/12668546/61447488-a379f700-a983-11e9-9956-139352a2585d.png" width="200" />| <img src="https://user-images.githubusercontent.com/12668546/65471913-ab827580-dea3-11e9-919c-870c9605c60f.png" width="200" />  | <img src="https://user-images.githubusercontent.com/12668546/66585418-5cce1e80-ebb9-11e9-91c0-56f658f09e27.png" width="200" /> <br />请备注：鲁班H5交流|

#### 需求收集
- [ ] 二级子域名
- [ ] 小程序
- [ ] 多浏览器适配
- [ ] 私有部署
- [ ] docker 部署
- [ ] PV、UV


---

> 如果有问题，欢迎大家到[鲁班H5-社区](https://support.qq.com/products/93432/) 交流，在这里可以提问、反馈意见和建议，与作者直接互动

<Vssue issueId="11" />