import Strapi from 'strapi-sdk-javascript'

const strapi = new Strapi()

export default strapi
