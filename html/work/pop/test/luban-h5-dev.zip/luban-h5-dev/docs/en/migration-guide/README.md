# Migrations guides

- [Migration guide from v.1.8.0 to v1.8.1](migration-guide-1.8.0-to-1.8.1.md)
- [Migration guide from v.1.8.1 to v1.8.2](migration-guide-1.8.1-to-1.8.2.md)