import Index from '../Index';

export default function () {
  return (
    <Index />
  );
}