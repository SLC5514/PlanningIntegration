::: intro
<!-- ![Logo](https://cldup.com/7umchwdUBh.png) -->
## 鲁班H5
鲁班H5是基于Vue2.0开发的，通过拖拽+配置的形式，生成页面的工具。

<img src="https://s2.ax1x.com/2019/10/11/u7WzUx.gif" height="290" />
<!-- ### 鲁班H5是什么？ -->

<!-- {p:.flex.justify-around} -->

---
:::

<Vssue issueId="14" />
