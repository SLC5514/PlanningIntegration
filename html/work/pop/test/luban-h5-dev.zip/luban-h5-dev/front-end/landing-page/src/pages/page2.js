import Page2 from '../Page2';

export default function () {
  return (
    <Page2 />
  );
}
