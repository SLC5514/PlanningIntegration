# 迁移指南

- [v.1.8.0 至 v.1.8.1 迁移指南](migration-guide-1.8.0-to-1.8.1.md)
- [v.1.8.1 至 v.1.8.2 迁移指南](migration-guide-1.8.1-to-1.8.2.md)