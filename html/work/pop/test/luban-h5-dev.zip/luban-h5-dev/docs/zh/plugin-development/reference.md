# 参考资料

1. Vue Cli3+
2. Grafana
3. Figma

---

<Vssue issueId="10" />