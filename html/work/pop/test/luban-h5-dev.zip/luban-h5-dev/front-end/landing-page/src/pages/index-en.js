import Index from '../Index-En';

export default function () {
  return (
    <Index />
  );
}